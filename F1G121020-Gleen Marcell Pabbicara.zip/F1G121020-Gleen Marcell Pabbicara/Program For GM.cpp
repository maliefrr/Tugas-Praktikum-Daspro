#include <iostream>
using namespace std;

int main()
{
    int banyak = 0;
    cout<<"Berapa banyak yang ingin dicetak : ";
    cin>>banyak;
    for(int i=banyak;i>=1;i--){
        for(int j=i;j>=1;j--){
            cout<< j << " " ;
        }
        cout<<endl;
    }
    for(int i=1;i<=banyak;i++){
        for(int j=1;j<=i;j++){
            cout<< j <<" ";
        }
        cout<<endl;
    }
}
