#include <iostream>
using namespace std;
int main()
{
    int nomor = 1, angka;
    cout << "Masukan angka berapa yang ingin dicetak? ";
    cin >> angka;
    while(nomor <= angka ){
        cout << "[" << nomor << "] ";
        nomor++;
    }
    return 0;
} 