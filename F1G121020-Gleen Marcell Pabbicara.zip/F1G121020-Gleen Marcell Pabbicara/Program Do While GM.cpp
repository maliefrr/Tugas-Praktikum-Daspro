#include <iostream>
using namespace std;
int main()
{
  int x,y;
  cout << "Bilangan Awal :";
  cin >> x;
  cout << "Hingga :";
  cin >> y;
  do{
    cout << x <<" x "<< x <<" = " << x*x << endl;
    x++;
    
  }
  while(x<=y);
  }
    