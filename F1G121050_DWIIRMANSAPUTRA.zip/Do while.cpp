#include<iostream>
using namespace std;

int main(){
	int L, p, l;
	string ulang;
	do{
		cout<<"======Menghitung Luas Persegi Panjang======"<<endl;
		cout<<"Masukan Panjang Persegi : ";
		cin>>p;
		cout<<"Masukuan Lebar Persegi : ";
		cin>>l;
		L = p * l;
		cout<<"Luas Persegi Panjang Adalah : "<<L<<endl;
		cout<<"Ulangi Proses (y/n)";
		cin>>ulang;
	} while (ulang == "y");
	cout<<"Program Selesai";
}
