#include<iostream>
using namespace std;

int main(){
	int Awal, Akhir;
	cout<<"Mulai Nila Berapa 	: ";
	cin>>Awal;
	cout<<"Sampai Nilai Berapa 	: ";
	cin>>Akhir;
	for (int a = Awal; a <= Akhir; a++){
		cout<<a<<". Nilai"<<endl;
	}
}
