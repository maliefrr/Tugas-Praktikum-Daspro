#include<iostream>
using namespace std;

int main(){
	int awal, akhir;
	cout<<"masukan angka awal 	: ";
	cin>>awal;
	cout<<"masukan angka akhir	: ";
	cin>>akhir;
	int b = awal;
	while(b <= akhir){
		cout<<b<<". angka"<<endl;
		b++;
	}
}
