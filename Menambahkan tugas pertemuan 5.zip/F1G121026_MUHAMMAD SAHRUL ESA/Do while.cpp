#include <iostream>
using namespace std;
int main()
{
  int j,b;
  cout<<"masukan bilangan mulai awal :";
  cin>>j;
  cout<<"inggin sampai berapa :";
  cin>>b;
  do{
    cout<<j<<" x "<<j<<" = "<<j*j<<endl;
    j++;
    
  }
  while(j<=b);
  }
    