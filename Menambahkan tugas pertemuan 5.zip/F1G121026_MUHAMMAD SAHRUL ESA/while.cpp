#include <iostream>
using namespace std;
int main()
{
    int j,b;
    cout<<"masukkan bilang mulai awal : ";
    cin>>j;
    cout<<"ingin sampai berapa : ";
    cin>>b;
    while(j<=10){
      cout<<j<<" x "<<j<<" = "<<j*j<<endl;
      j++;
    }
    
}